<!DOCTYPE html>
<?php
setcookie("user", "test", time() + 7200, '/');
?>
<html lang="pl">
    <head>
        <meta charset="UTF-8">
        <title>Port Lotniczy</title>
        <link rel="stylesheet" href="styl5.css">
    </head>
    <body>
        <div class="baner1">
            <img src="zad5.png" alt="logo lotnisko">
        </div>    
        <div class="baner2">
            <h1>Przyloty</h1>
        </div>
        <div class="baner3">
            <h3>przydatne linki</h3>
            <a href="kwerendy.txt" target="_blank">Pobierz</a>
            </div>
            <main>
            <table>
                <tr>
                    <th>czas</th>
                    <th>kierunek</th>
                    <th>numer rejsu</th>
                    <th>status</th>
                </tr>
                <?php
                $db = mysqli_connect('localhost', 'root', '', 'egzamin1');
            $q = 'SELECT czas, kierunek, nr_rejsu, status_lotu FROM przyloty ORDER BY czas;';
            
            $result = mysqli_query($db, $q);

            while($row = mysqli_fetch_array($result)){
                echo '<tr>';
                    echo '<td>'.$row["czas"].'</td>';
                    echo '<td>'.$row["kierunek"].'</td>';
                    echo '<td>'.$row["nr_rejsu"].'</td>';
                    echo '<td>'.$row["status_lotu"].'</td>';
                echo '</tr>';
            }
            ?>
            </table>
        </main>
        <div class="stopka1">
            <?php
            if(!isset($_COOKIE["user"])){
                echo"<p><b>Dzień dobry! Strona używa ciasteczek</b></p>";
            } else {
                echo "<p><i>Witaj ponownie na stronie lotniska</i></p>";
            }
            ?>
        </div>
        <div class="stopka2">
            <p>Autor: Jakub Gudebski 3a</p>
        </div>
    </body>
</html>