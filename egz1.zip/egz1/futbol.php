<!DOCTYPE html>
<html lang="pl">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Rozgrywki futbolowe</title>
        <link rel="stylesheet" href="styl.css">
    </head>
    <body>
        <header>
            <h2>Światowe rozgrywki piłkarskie</h2>
            <img src="obraz1.jpg" alt="boisko">
        </header>
        <section id="mecze">
            <ul>
                <?php
                $host = 'localhost';
                $user = 'root';
                $passwrord = '';
                $dbname = 'egzamin';

                $db = mysqli_connect($host, $user, $passwrord, $dbname);

                $q = 'SELECT zespol1, zespol2, wynik, data_rozgrywki FROM rozgrywka WHERE zespol1 = "EVG";';

                $result = mysqli_query($db, $q);

                while($row = mysqli_fetch_array($result)){
                echo '<div class="rozgrywka">
                    <h3>'.$row["zespol1"].' - '.$row["zespol2"].'</h3>
                    <h4>'.$row["wynik"].'</h4>
                    <p>w dniu: '.$row["data_rozgrywki"].'</p>
                    </div>';
                }
                ?>  
            </ul>
        </section>
        <main>
            <h2>Reprezentacja Polski</h2>
        </main>
        <section id="lewy">
            <p>Podaj pozycję zawodników (1-bramkarze, 2-obrońcy, 3-pomocnicy, 4-napastinicy):</p>
            <form action="futbol.php" method="post">
                <input type="number" name="numer" id="zawodnik">
                <button type="submit" name="formularz">Sprawdź</button>
            </form>
            <ul>
                <?php
                if(isset($_POST['formularz'])){
                    $numer = $_POST['numer'];
                    if($numer!=""){
                        $q = 'SELECT imie, nazwisko FROM zawodnik WHERE pozycja_id = "'.$numer.'";';

                        $result = mysqli_query($db, $q);

                        while($row = mysqli_fetch_array($result)){
                            echo '<li><p>'.$row["imie"].' '.$row["nazwisko"].'</p></li>';
                        }
                    }
                }
                mysqli_close($db);
                ?>
            </ul>
        </section>
        <section id="prawy">
            <img src="zad1.png" alt="piłkarz">
            <p>Autor Jakub G</p>
        </section>
    </body>
</html>