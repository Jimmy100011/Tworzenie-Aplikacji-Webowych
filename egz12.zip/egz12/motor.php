<!DOCTYPE html>
<html lang="pl">
    <head>
        <meta charset="UTF-8">
        <title>Motocykle</title>
        <link rel="stylesheet" href="styl.css">
    </head>
    <body>
        <img src="motor.png" alt="motocykl">
        
        <header>
            <h1>Motocykle - moja pasja</h1>
        </header>

        <main>
            <h2>Gdzie pojechać?</h2>
            <?php
            $db = mysqli_connect('localhost', 'root', '', 'motor');
            $q = 'SELECT nazwa, opis, poczatek, zrodlo FROM wycieczki JOIN zdjecia ON zdjecia_id = zdjecia.id;';
            
            $result = mysqli_query($db, $q);

            while($row = mysqli_fetch_array($result)){
                echo '<dt>'Termin listy:'.$row['nazwa'].'rozpoczyna się w '.$row['poczatek'].';
                echo '<dd>'
            }
            ?>
        </main>

        <div class="prawy1">
            <h2>Co kupić?</h2>
            <ol>
                <li>Honda CBR125R</li>
                <li>Yamaha YBR125</li>
                <li>Honda VFR800i</li>
                <li>Honda CBR1100XX</li>
                <li>BMW R1200GS LC</li>
            </ol>
        </div>

        <div class="prawy2">
            <h2>Statystyki</h2>
            <?php
            $q = "SELECT COUNT(*) FROM wycieczki;";

            $result = mysqli_fetch_array($db, $q);

            while($row = mysqli_fetch_array($result)){
                echo '<p>Wpisanych wycieczek: $liczba</p>';
            }
            ?>
            <p>Użytkowników forum: 200</p>
            <p>Przesłanych zdjęć: 1300</p>
        </div>

        <footer>
            <p><a>Autor: Jakub Gudebski 3A</a></p>
        </footer>

    </body>
</html>