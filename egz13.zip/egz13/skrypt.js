function aktywujPole(pole){
    var pole1 = document.getElementById("pole1");
    var pole2 = document.getElementById("pole2");
    var pole3 = document.getElementById("pole3");
    if(pole === "klient"){
        pole1.style.display = "block";
        pole2.style.display = "none";
        pole3.style.display = "none";
    }
    if(pole === "adres"){
        pole1.style.display = "none";
        pole2.style.display = "block";
        pole3.style.display = "none";
    }
    if(pole === "kontakt"){
        pole1.style.display = "none";
        pole2.style.display = "none";
        pole3.style.display = "block";
    }
}
var progress = 4;
function zaktualizujPasekPostepu(){
    var postep = document.getElementById("postep");
    if(progress<100){
        progress += 12;
    }
    if(progress>100){
        progress = 100;
    }
    postep.style.width = progress + "%";
}

function pobierzDane(){
    imie = document.getElementById("imie").value;
    nazwisko = document.getElementById("nazwisko").value;
    data = document.getElementById("data").value;
    ulica = document.getElementById("ulica").value;
    numer = document.getElementById("numer").value;
    miasto = document.getElementById("miasto").value;
    telefon = document.getElementById("telefon").value;
    rodo = document.getElementById("rodo").value;

    console.log(imie, nazwisko, data, ulica, numer, miasto, telefon, rodo);
}